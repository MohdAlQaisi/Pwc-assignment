﻿using App.Api;
using App.Core;
using App.Core.DTOs;
using App.Core.Entities;
using App.Core.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System.Collections.Generic;
using System.Linq;

namespace App.ApiControllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    public class AccountController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;
        private readonly AppSettings _appSettings;
        private readonly ISvcAccount _svcAccount;

        public AccountController(IOptions<AppSettings> appSettings,
            ISvcAccount svcAccount,
            SignInManager<ApplicationUser> signInManager,
            UserManager<ApplicationUser> userManager)
        {
            _svcAccount = svcAccount;
            _userManager = userManager;
            _signInManager = signInManager;
            _appSettings = appSettings.Value;
        }

        [HttpPost]
        [AllowAnonymous]
        [Route("Login")]
        public IActionResult Login([FromBody] UserLoginDto userModel)
        {
            Microsoft.AspNetCore.Identity.SignInResult result = null;
            try
            {
                result = _signInManager.PasswordSignInAsync(userModel.Email, userModel.Password, userModel.RememberMe, false).Result;
                if (result.Succeeded)
                {
                    var user = _svcAccount.GetUser(p => p.Email == userModel.Email).Data;
                    return Ok(user.GetToken(_appSettings));
                }
                else
                {
                    return Unauthorized();
                }
            }
            catch
            {
                return Unauthorized();
            }
        }

        [HttpPost]
        [AllowAnonymous]
        [Route("CustomerRegister")]
        public IActionResult CustomerRegister([FromBody] ApplicationUserDto userDto)
        {
            if (ModelState.IsValid)
            {
                var user = new ApplicationUser()
                {
                    FullName = userDto.FullName,
                    ContactNumber = userDto.ContactNumber,
                    Email = userDto.Email,
                    NormalizedEmail = userDto.Email.ToUpper(),
                    UserName = userDto.Email,
                    NormalizedUserName = userDto.Email.ToUpper(),
                };

                IdentityResult result = _userManager.CreateAsync(user, userDto.Password).Result;

                if (result.Succeeded)
                    _userManager.AddToRoleAsync(user, Roles.Customer).Wait();

                if (result.Succeeded)
                {
                    return Ok(new ActionResultSet<string>()
                    {
                        IsSuccess = result.Succeeded,
                        Data = user.GetToken(_appSettings)
                    });
                }
                else
                {
                    return Ok(new ActionResultSet<string>()
                    {
                        IsSuccess = result.Succeeded,
                        Data = string.Join(" - ", result.Errors.Select(p => p.Description).ToList())
                    });
                }
            }
            else
            {
                return Ok(new ActionResultSet<List<string>>()
                {
                    IsSuccess = false
                });
            }
        }

        [HttpPost]
        [Route("AdminRegister")]
        public IActionResult AdminRegister([FromBody] ApplicationUserDto userDto)
        {
            if (ModelState.IsValid)
            {
                var user = new ApplicationUser()
                {
                    FullName = userDto.FullName,
                    ContactNumber = userDto.ContactNumber,
                    Email = userDto.Email,
                    NormalizedEmail = userDto.Email.ToUpper(),
                    UserName = userDto.Email,
                    NormalizedUserName = userDto.Email.ToUpper(),
                };

                IdentityResult result = _userManager.CreateAsync(user, userDto.Password).Result;

                if (result.Succeeded)
                    _userManager.AddToRoleAsync(user, Roles.Admin).Wait();

                if (result.Succeeded)
                {
                    return Ok(new ActionResultSet<string>()
                    {
                        IsSuccess = result.Succeeded,
                    });
                }
                else
                {
                    return Ok(new ActionResultSet<string>()
                    {
                        IsSuccess = result.Succeeded,
                        Data = string.Join(" - ", result.Errors.Select(p => p.Description).ToList())
                    });
                }
            }
            else
            {
                return Ok(new ActionResultSet<List<string>>()
                {
                    IsSuccess = false
                });
            }
        }
    }
}
