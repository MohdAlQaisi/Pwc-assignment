﻿using App.Core;
using App.Core.Services;
using App.Infra;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace App.ApiControllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    public class ComplaintController : Controller
    {
        private readonly AppSettings _appSettings;
        private readonly ISvcComplaint _svcComplaint;

        public ComplaintController(IOptions<AppSettings> appSettings, ISvcComplaint svcComplaint)
        {
            _svcComplaint = svcComplaint;
            _appSettings = appSettings.Value;
        }

        [HttpGet]
        [Route("GetComplaint")]
        public IActionResult GetComplaint(int id)
        {
            var complaint = _svcComplaint.GetComplaint(c => c.Id == id, c => c.ActionType);

            var result = complaint.Map();

            return Ok(new ActionResultSet<ComplaintDto>()
            {
                IsSuccess = true,
                Data = result
            });
        }

        [HttpGet]
        [Route("GetComplaints")]
        public IActionResult GetComplaints([FromQuery] int batch = 1, [FromQuery] int batchSize = 100)
        {
            var paging = new Paging(batch, batchSize);

            var complaint = _svcComplaint.GetComplaints(paging, null, c => c.ActionType, c => c.CreatedBy);

            var result = complaint.Map();

            return Ok(new ActionResultSet<SearchResult<ComplaintDto>>()
            {
                IsSuccess = true,
                Data = new SearchResult<ComplaintDto>(result, paging)
            });
        }

        [HttpGet]
        [Route("GetCustomerComplaints")]
        public IActionResult GetCustomerComplaints([FromQuery] int batch = 1, [FromQuery] int batchSize = 100)
        {
            var paging = new Paging(batch, batchSize);

            var userId = User.GetUserId();

            var complaint = _svcComplaint.GetComplaints(paging, c=> c.CreatedByUserId == userId, c => c.ActionType);

            var result = complaint.Map();

            return Ok(new ActionResultSet<SearchResult<ComplaintDto>>()
            {
                IsSuccess = true,
                Data = new SearchResult<ComplaintDto>(result, paging)
            });
        }

        [HttpPost]
        [Route("SubmitComplaint")]
        public IActionResult SubmitComplaint([FromBody] ComplaintDto complaintDto)
        {
            _svcComplaint.AddNewComplaint(complaintDto, User.GetUserId());

            return Ok(new ActionResultSet<string>()
            {
                IsSuccess = true,
                Data = "Complaint submitted successfully"
            });
        }

        [HttpPost]
        [Route("TakeAction")]
        public IActionResult TakeAction([FromBody] ComplaintActionDto complaintActionDto)
        {
            _svcComplaint.TakeAction(complaintActionDto, User.GetUserId());

            return Ok(new ActionResultSet<string>()
            {
                IsSuccess = true,
                Data = "Complaint action taken successfully"
            });
        }
    }
}
