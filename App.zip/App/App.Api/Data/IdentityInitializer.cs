﻿using App.Core;
using App.Core.Entities;
using Microsoft.AspNetCore.Identity;

namespace App.Api
{
    public static class IdentityInitializer
    {
        public static void Create(UserManager<ApplicationUser> userManager, RoleManager<ApplicationRole> roleManager)
        {
            try
            {
                CreateRoles(roleManager);
                CreateUsers(userManager);
            }
            catch
            {
            }
        }

        public static void CreateUsers(UserManager<ApplicationUser> userManager)
        {
            if (userManager.FindByNameAsync("admin@app.com").Result == null)
            {
                ApplicationUser user = new ApplicationUser();
                user.UserName = "admin@app.com";
                user.Email = "admin@app.com";
                user.FullName = "admin";
                IdentityResult result = userManager.CreateAsync(user, "P@ssw0rd").Result;

                if (result.Succeeded)
                    userManager.AddToRoleAsync(user, Roles.Admin).Wait();
            }
        }

        public static void CreateRoles(RoleManager<ApplicationRole> roleManager)
        {
            if (!roleManager.RoleExistsAsync(Roles.Admin).Result)
            {
                ApplicationRole role = new()
                {
                    Name = Roles.Admin
                };
                _ = roleManager.CreateAsync(role).Result;
            }


            if (!roleManager.RoleExistsAsync(Roles.Customer).Result)
            {
                ApplicationRole role = new()
                {
                    Name = Roles.Customer
                };
                _ = roleManager.CreateAsync(role).Result;
            }
        }
    }
}
