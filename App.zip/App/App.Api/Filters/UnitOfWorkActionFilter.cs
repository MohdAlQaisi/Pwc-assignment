﻿using App.DAL;
using Microsoft.AspNetCore.Mvc.Filters;

namespace App.Api.Filters
{
    internal class UnitOfWorkActionFilter : IActionFilter
    {
        private IUnitOfWork UnitOfWork = null;

        public UnitOfWorkActionFilter(IUnitOfWork unitOfWork)
        {
            UnitOfWork = unitOfWork;
        }

        public void OnActionExecuting(ActionExecutingContext context)
        {
        }
        public void OnActionExecuted(ActionExecutedContext context)
        {
            if (context.Exception == null || context.ExceptionHandled)
            {
                UnitOfWork.End();
            }
            else
            {
                UnitOfWork.Rollback();
            }
        }
    }
}