﻿using System.Linq;
using System.Security.Claims;

namespace App
{
    public static class Extensions
    {
        public static string GetUserId(this ClaimsPrincipal user)
        {
            return ((ClaimsIdentity)user.Identity).Claims.FirstOrDefault(p => p.Type == "id").Value;
        }

        public static string GetUserEmail(this ClaimsPrincipal user)
        {
            return ((ClaimsIdentity)user.Identity).Claims.FirstOrDefault(p => p.Type == "emailaddress").Value;
        }

        public static string GetUserFullName(this ClaimsPrincipal user)
        {
            return ((ClaimsIdentity)user.Identity).Claims.FirstOrDefault(p => p.Type == "name").Value;
        }

        public static string GetUserMobilePhone(this ClaimsPrincipal user)
        {
            return ((ClaimsIdentity)user.Identity).Claims.FirstOrDefault(p => p.Type == "mobilephone").Value;
        }
    }
}
