﻿using App.Core;
using App.Core.Entities;
using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;

namespace App.Api
{
    public static class TokenHelper
    {
        public static string GetToken(this ApplicationUser user, AppSettings _appSettings)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_appSettings.Secret);
            var role = user.UserRoles.FirstOrDefault()?.Role.Name;
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
                    new Claim("id", user.Id),
                    new Claim("mobilephone", user.ContactNumber ?? string.Empty),
                    new Claim("emailaddress", user.Email ?? string.Empty),
                    new Claim("fullname", user.FullName ?? string.Empty),
                    new Claim("role", role ?? string.Empty),
                }),
                Expires = DateTime.UtcNow.AddDays(7),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }
    }
}
