﻿namespace App.Core
{
    public static class Roles
    {
        public static string Admin = "Admin";
        public static string Customer = "Customer";
    }
}
