﻿namespace App.Core
{
    public class ActionResultSet<T>
    {
        public bool IsSuccess { get; set; } = false;
        public T Data { get; set; }
    }
}
