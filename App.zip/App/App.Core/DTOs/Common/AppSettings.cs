﻿namespace App.Core
{
    public class AppSettings
    {
        public string Connection { get; set; }
        public string Secret { get; set; }
        public int TokenValidity { get; set; }
    }
}
