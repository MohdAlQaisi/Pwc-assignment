﻿using System.ComponentModel.DataAnnotations;

namespace App.Core
{
    public class Paging
    {
        public Paging()
        {

        }

        public Paging(int batch, int batchSize)
        {
            Batch = batch;
            BatchSize = batchSize;
        }

        public int Batch { get; set; } = 1;

        public int BatchSize { get; set; } = 100;

        public int TotalRecords { get; set; }
    }
}
