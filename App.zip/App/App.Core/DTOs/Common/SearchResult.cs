﻿using System.Collections.Generic;

namespace App.Core
{
    public class SearchResult<T>
    {
        public SearchResult()
        {

        }
        public SearchResult(IEnumerable<T> list, Paging paging)
        {
            List = list;
            Paging = paging;
        }
        public IEnumerable<T> List { get; set; }
        public Paging Paging { get; set; }
    }
}
