﻿namespace App.Core.Models
{
    public class SpecificationResult
    {
        public bool Passed { get; set; }
        public ValidationMessage Error { get; set; }
    }
}
