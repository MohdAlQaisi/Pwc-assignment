﻿namespace App.Core
{
    public class ValidationMessage
    {
        public string Code { get; set; }
        public string Message { get; set; }
        public string ExceptionMessage { get; set; }
    }
}
