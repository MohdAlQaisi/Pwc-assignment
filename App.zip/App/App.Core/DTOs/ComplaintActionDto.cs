﻿using App.Core.Enums;

namespace App.Core
{
    public class ComplaintActionDto
    {
        public int ComplaintId { get; set; }
        public ComplaintActionTypes ActionType { get; set; }
    }
}
