﻿using App.Core.Enums;
using System;
using System.ComponentModel.DataAnnotations;

namespace App.Core
{
    public class ComplaintDto
    {
        public int Id { get; set; }

        [Required]
        [StringLength(250, MinimumLength = 2)]
        public string Title { get; set; }

        public string Type { get; set; }

        [Required]
        public string Description { get; set; }
        public string DescriptionText { get; set; }

        public string Status { get; set; }
        public ComplaintActionTypes StatusId { get; set; }
        public string CreatedBy { get; set; }
        public string CreationDate { get; set; }
    }
}
