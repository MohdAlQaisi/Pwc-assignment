﻿using System.ComponentModel.DataAnnotations;

namespace App.Core.DTOs
{
    public class ApplicationUserDto
    {
        [Required(AllowEmptyStrings = false)]
        [StringLength(100, MinimumLength = 2)]
        public string FullName { get; set; }

        public string ContactNumber { get; set; }

        [Required(AllowEmptyStrings = false)]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        public string Password { get; set; }
    }
}
