﻿using App.Core.Enums;

namespace App.Core.Entities
{
    public class ActionType : LookupBase
    {
        public ComplaintActionTypes Id { get; set; }
    }
}
