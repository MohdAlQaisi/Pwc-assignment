﻿using System;

namespace App.Core.Entities
{
    public class DomainBase
    {
        public string CreatedByUserId { get; set; }
        public ApplicationUser CreatedBy { get; set; }
        public DateTime CreationDate { get; set; } = DateTime.Now;
    }
}
