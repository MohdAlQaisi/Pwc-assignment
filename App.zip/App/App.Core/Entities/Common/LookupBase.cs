﻿namespace App.Core.Entities
{
    public class LookupBase : DomainBase
    {
        public string Title { get; set; }
    }
}
