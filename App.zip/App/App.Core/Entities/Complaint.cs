﻿using App.Core.Enums;
using System.Collections.Generic;

namespace App.Core.Entities
{
    public class Complaint : DomainBase
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Type { get; set; }
        public string Description { get; set; }
        public string DescriptionText { get; set; }
        public ComplaintActionTypes ActionTypeId { get; set; }
        public ActionType ActionType { get; set; }
        public List<ComplaintAction> ActionLogs { get; set; }
    }
}
