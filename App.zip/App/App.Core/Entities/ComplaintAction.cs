﻿using App.Core.Enums;

namespace App.Core.Entities
{
    public class ComplaintAction : DomainBase
    {
        public int Id { get; set; }
        public ComplaintActionTypes ActionTypeId { get; set; }
        public ActionType ActionType { get; set; }
        public int ComplaintId { get; set; }
        public Complaint Complaint { get; set; }
    }
}
