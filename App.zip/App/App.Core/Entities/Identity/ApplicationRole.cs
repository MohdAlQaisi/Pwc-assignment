﻿using Microsoft.AspNetCore.Identity;
using System.Collections.Generic;

namespace App.Core.Entities
{
    public class ApplicationRole : IdentityRole
    {
        public ICollection<UserRole> UserRoles { get; set; }
    }
}
