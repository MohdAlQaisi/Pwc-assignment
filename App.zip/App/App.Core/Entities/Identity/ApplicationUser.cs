﻿using Microsoft.AspNetCore.Identity;
using System.Collections.Generic;

namespace App.Core.Entities
{
    public class ApplicationUser : IdentityUser
    {
        public ApplicationUser()
        {
        }
        public string FullName { get; set; }
        public string ContactNumber { get; set; }
        public ICollection<UserRole> UserRoles { get; set; }
    }
}
