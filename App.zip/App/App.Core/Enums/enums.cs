﻿namespace App.Core.Enums
{
    public enum ComplaintActionTypes
    {
        Pending = 0,
        Resolved = 1,
        Dismissed = 2,
    }
}