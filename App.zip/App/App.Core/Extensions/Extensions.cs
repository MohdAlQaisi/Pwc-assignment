﻿using System;
using System.Linq;
using System.Text;

namespace App.Core
{
    public static class Extensions
    {
        public static byte[] EncodeKey(this string secretKey)
        {
            return Encoding.ASCII.GetBytes(secretKey);
        }

        public static T Clone<T>(this T source) where T : class
        {
            var dest = Activator.CreateInstance<T>();
            var sourceProps = typeof(T).GetProperties().Where(x => x.CanRead).ToList();

            foreach (var sourceProp in sourceProps)
            {
                var p = sourceProps.First(x => x.Name == sourceProp.Name);
                p.SetValue(dest, sourceProp.GetValue(source, null), null);
            }
            return dest;
        }
    }
}
