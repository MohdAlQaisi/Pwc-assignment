﻿namespace App.Core.Services
{
    public interface ISvc
    {
    }
}
