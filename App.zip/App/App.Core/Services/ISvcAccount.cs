﻿using App.Core.Entities;
using System;
using System.Linq.Expressions;

namespace App.Core.Services
{
    public interface ISvcAccount : ISvc
    {
        ActionResultSet<ApplicationUser> GetUser(Expression<Func<ApplicationUser, bool>> expression);
        ActionResultSet<bool> AddUser(ApplicationUser user);
    }
}
