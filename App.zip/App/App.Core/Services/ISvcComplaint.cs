﻿using App.Core.Entities;
using App.Core.Enums;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;

namespace App.Core.Services
{
    public interface ISvcComplaint : ISvc
    {
        Complaint GetComplaint(Expression<Func<Complaint, bool>> expression, params Expression<Func<Complaint, object>>[] includeExpressions);
        List<Complaint> GetComplaints(Paging paging, Expression<Func<Complaint, bool>> expression, params Expression<Func<Complaint, object>>[] includeExpressions);
        void AddNewComplaint(ComplaintDto complaintDto, string userId);
        void TakeAction(ComplaintActionDto complaintActionDto, string userId);
    }
}
