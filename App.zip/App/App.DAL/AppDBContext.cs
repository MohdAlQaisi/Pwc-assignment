﻿using App.Core.Entities;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;

namespace App.DAL
{
    public class AppDBContext : IdentityDbContext<ApplicationUser, ApplicationRole, string, IdentityUserClaim<string>, UserRole, IdentityUserLogin<string>, IdentityRoleClaim<string>, IdentityUserToken<string>>
    {
        public AppDBContext(DbContextOptions option) : base(option)
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.EntitiesModelBuilder();

            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<UserRole>(userRole =>
            {
                userRole.HasKey(ur => new { ur.UserId, ur.RoleId });

                userRole.HasOne(ur => ur.Role)
                    .WithMany(r => r.UserRoles)
                    .HasForeignKey(ur => ur.RoleId)
                    .IsRequired();

                userRole.HasOne(ur => ur.User)
                    .WithMany(r => r.UserRoles)
                    .HasForeignKey(ur => ur.UserId)
                    .IsRequired();
            });
        }

        public object Any(Func<object, bool> p)
        {
            throw new NotImplementedException();
        }
    }

    public static class ModelsContext
    {
        public static void EntitiesModelBuilder(this ModelBuilder modelBuilder)
        {
            #region ActionType
            modelBuilder.Entity<ActionType>().ToTable("ActionTypes").HasKey(p => p.Id);

            modelBuilder.Entity<ActionType>()
                .HasOne(at => at.CreatedBy)
                .WithMany()
                .HasForeignKey(c => c.CreatedByUserId)
                .IsRequired();
            #endregion

            #region ComplaintAction
            modelBuilder.Entity<ComplaintAction>().ToTable("ComplaintActions").HasKey(p => p.Id);

            modelBuilder.Entity<ComplaintAction>()
                .HasOne(at => at.CreatedBy)
                .WithMany()
                .HasForeignKey(c => c.CreatedByUserId)
                .IsRequired();

            modelBuilder.Entity<ComplaintAction>()
                .HasOne(ca => ca.ActionType)
                .WithMany()
                .HasForeignKey(ca => ca.ActionTypeId)
                .IsRequired();

            modelBuilder.Entity<ComplaintAction>()
                .HasOne(ca => ca.Complaint)
                .WithMany(ca => ca.ActionLogs)
                .HasForeignKey(ca => ca.ComplaintId)
                .IsRequired();
            #endregion

            #region Complaint
            modelBuilder.Entity<Complaint>().ToTable("Complaints").HasKey(p => p.Id);

            modelBuilder.Entity<Complaint>()
                .HasOne(at => at.CreatedBy)
                .WithMany()
                .HasForeignKey(c => c.CreatedByUserId)
                .IsRequired();

            modelBuilder.Entity<Complaint>()
                .HasOne(c => c.ActionType)
                .WithMany()
                .HasForeignKey(c => c.ActionTypeId)
                .IsRequired();
            #endregion
        }
    }
}
