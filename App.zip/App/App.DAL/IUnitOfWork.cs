﻿using System;

namespace App.DAL
{
    public interface IUnitOfWork : IDisposable
    {
        int Id { get; set; }
        AppDBContext DatabaseContext { get; }
        void Commit();
        void End();
        void Rollback();
        void SetToBeCommitted();
    }
}
