﻿using Fluentx;
using Microsoft.EntityFrameworkCore;
using System;
using System.Data;
using System.Threading.Tasks;

namespace App.DAL
{
    public static class With
    {
        public static TResult Transaction<TResult>(IUnitOfWork unitOfWork, Func<AppDBContext, TResult> transactional)
        {
            unitOfWork.SetToBeCommitted();

            Guard.Against<ArgumentNullException>(transactional.IsNull());

            unitOfWork.DatabaseContext.ChangeTracker.AutoDetectChangesEnabled = true;
            unitOfWork.DatabaseContext.ChangeTracker.LazyLoadingEnabled = false;

            if (unitOfWork.DatabaseContext.Database.CurrentTransaction == null)
            {
                unitOfWork.DatabaseContext.Database.BeginTransaction(IsolationLevel.ReadCommitted);
            }
            try
            {
                TResult result = transactional(unitOfWork.DatabaseContext);
                return result;
            }
            catch (Exception ex) { throw ex; }
        }
        public static void Transaction(IUnitOfWork unitOfWork, Action<AppDBContext> transactional)
        {
            unitOfWork.SetToBeCommitted();

            Guard.Against<ArgumentNullException>(transactional.IsNull());

            unitOfWork.DatabaseContext.ChangeTracker.AutoDetectChangesEnabled = true;
            unitOfWork.DatabaseContext.ChangeTracker.LazyLoadingEnabled = false;
            if (unitOfWork.DatabaseContext.Database.CurrentTransaction == null)
            {
                unitOfWork.DatabaseContext.Database.BeginTransaction(IsolationLevel.ReadCommitted);
            }
            try
            {
                transactional(unitOfWork.DatabaseContext);
            }
            catch (Exception e)

            { throw e; }

        }
        public static TResult Action<TResult>(IUnitOfWork unitOfWork, Func<AppDBContext, TResult> actional)
        {
            Guard.Against<ArgumentNullException>(actional.IsNull());
            TResult result = actional(unitOfWork.DatabaseContext);
            return result;
        }
        public static async Task<TResult> ActionAsync<TResult>(IUnitOfWork unitOfWork, Func<AppDBContext, Task<TResult>> actional)
        {
            Guard.Against<ArgumentNullException>(actional.IsNull());

            TResult result = await actional(unitOfWork.DatabaseContext);
            unitOfWork.DatabaseContext.ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;
            unitOfWork.DatabaseContext.ChangeTracker.AutoDetectChangesEnabled = false;
            unitOfWork.DatabaseContext.ChangeTracker.LazyLoadingEnabled = false;
            return result;
        }
        public static async Task<TResult> ActionAsyncParallel<TResult>(IUnitOfWork unitOfWork, Func<AppDBContext, Task<TResult>> actional)
        {
            Guard.Against<ArgumentNullException>(actional.IsNull());

            TResult result = await actional(unitOfWork.DatabaseContext);
            unitOfWork.DatabaseContext.ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;
            unitOfWork.DatabaseContext.ChangeTracker.AutoDetectChangesEnabled = false;
            unitOfWork.DatabaseContext.ChangeTracker.LazyLoadingEnabled = false;
            return result;
        }
        public static void Action(IUnitOfWork unitOfWork, Action<AppDBContext> actional)
        {
            Guard.Against<ArgumentNullException>(actional.IsNull());
            unitOfWork.DatabaseContext.ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;
            unitOfWork.DatabaseContext.ChangeTracker.AutoDetectChangesEnabled = false;
            unitOfWork.DatabaseContext.ChangeTracker.LazyLoadingEnabled = false;
            actional(unitOfWork.DatabaseContext);
        }
        public static async Task ActionAsync(IUnitOfWork unitOfWork, Func<AppDBContext, Task> actional)
        {
            Guard.Against<ArgumentNullException>(actional.IsNull());
            unitOfWork.DatabaseContext.ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;
            unitOfWork.DatabaseContext.ChangeTracker.AutoDetectChangesEnabled = false;
            unitOfWork.DatabaseContext.ChangeTracker.LazyLoadingEnabled = false;
            await actional(unitOfWork.DatabaseContext);
        }
    }
}
