﻿using App.Core;
using App.Core.Entities;
using App.Core.Enums;
using System.Collections.Generic;

namespace App.Infra
{
    public static class ComplaintMapping
    {
        public static IEnumerable<ComplaintDto> Map(this List<Complaint> complaints)
        {
            foreach (var complaint in complaints)
            {
                yield return complaint.Map();
            }
        }

        public static ComplaintDto Map(this Complaint complaint)
        {
            return new ComplaintDto()
            {
                Id = complaint.Id,
                Description = complaint.Description,
                DescriptionText = complaint.DescriptionText,
                Title = complaint.Title,
                Type = complaint.Type,
                Status = complaint.ActionType.Title,
                StatusId = complaint.ActionTypeId,
                CreatedBy = complaint.CreatedBy?.FullName,
                CreationDate = complaint.CreationDate.ToString("dd/MM/yyyy")
            };
        }

        public static Complaint ToAddedEntity(this ComplaintDto complaint, string userId)
        {
            return new Complaint()
            {
                Description = complaint.Description,
                DescriptionText = complaint.DescriptionText,
                Title = complaint.Title,
                Type = complaint.Type,
                CreatedByUserId = userId,
                ActionTypeId = ComplaintActionTypes.Pending,
                ActionLogs = new List<ComplaintAction>()
                {
                    new ComplaintAction()
                    {
                        CreatedByUserId = userId,
                        ActionTypeId = ComplaintActionTypes.Pending
                    }
                }
            };
        }
    }
}
