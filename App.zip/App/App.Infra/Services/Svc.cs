﻿using App.Core.Services;
using App.DAL;
using System;

namespace App.Infra.Services
{
    public class Svc : ISvc
    {
        public readonly IUnitOfWork unitOfWork;
        public Svc(IUnitOfWork _unitOfWork)
        {
            this.unitOfWork = _unitOfWork;
        }

        public T Transaction<T>(Func<AppDBContext, T> transactional)
        {
            return With.Transaction(unitOfWork, context =>
            {
                var result = transactional(context);
                return result;
            });
        }
    
        public void Transaction(Action<AppDBContext> transactional)
        {
            With.Transaction(unitOfWork, context =>
            {
                transactional(context);
            });
        }

        public T Action<T>(Func<AppDBContext, T> actional)
        {
            return With.Action(unitOfWork, context =>
            {
                var result = actional(context);
                return result;
            });
        }

        public void Action(Action<AppDBContext> actional)
        {
            With.Action(unitOfWork, context =>
            {
                actional(context);
            });
        }
    }
}
