﻿using App.Core;
using App.Core.Entities;
using App.Core.Services;
using App.DAL;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Linq.Expressions;

namespace App.Infra.Services
{
    public class SvcAccount : Svc, ISvcAccount
    {
        public SvcAccount(IUnitOfWork unitOfWork) : base(unitOfWork)
        {

        }

        public ActionResultSet<ApplicationUser> GetUser(Expression<Func<ApplicationUser, bool>> expression)
        {
            return Action(context =>
            {
                ApplicationUser user = null;
                try
                {
                    user = context.Set<ApplicationUser>()
                    .Include(p => p.UserRoles).ThenInclude(p => p.Role)
                    .FirstOrDefault(expression);
                }
                catch
                {
                    //couldn't get user
                }

                return new ActionResultSet<ApplicationUser>()
                {
                    Data = user,
                    IsSuccess = user != null
                };
            });
        }

        public ActionResultSet<bool> AddUser(ApplicationUser user)
        {
            return Transaction(context =>
            {
                context.Set<ApplicationUser>().Add(user);

                return new ActionResultSet<bool>()
                {
                    IsSuccess = true,
                    Data = true
                };
            });
        }
    }
}
