﻿using App.Core;
using App.Core.Entities;
using App.Core.Enums;
using App.Core.Services;
using App.DAL;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

namespace App.Infra.Services
{
    public class SvcComplaint : Svc, ISvcComplaint
    {
        public SvcComplaint(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
        }

        public Complaint GetComplaint(Expression<Func<Complaint, bool>> expression, params Expression<Func<Complaint, object>>[] includeExpressions)
        {
            return Action(context =>
            {
                var query = context.Set<Complaint>().AsQueryable();

                if (includeExpressions != null && includeExpressions.Any())
                {
                    foreach (var includeExpression in includeExpressions)
                    {
                        query = query.Include(includeExpression);
                    }
                }

                var complaint = query.FirstOrDefault(expression);
                return complaint;
            });
        }

        public List<Complaint> GetComplaints(Paging paging, Expression<Func<Complaint, bool>> expression, params Expression<Func<Complaint, object>>[] includeExpressions)
        {
            return Action(context =>
            {
                var query = context.Set<Complaint>().AsQueryable();

                if (includeExpressions != null && includeExpressions.Any())
                {
                    foreach (var includeExpression in includeExpressions)
                    {
                        query = query.Include(includeExpression);
                    }
                }

                if (expression != null)
                    query = query.Where(expression);

                paging.TotalRecords = query.Count();

                query = query.OrderByDescending(p => p.CreationDate);

                query = query.Skip(paging.Batch * paging.BatchSize - paging.BatchSize);

                query = query.Take(paging.BatchSize);

                var complaints = query.ToList();

                return complaints;
            });
        }

        public void AddNewComplaint(ComplaintDto complaintDto, string userId)
        {
            Transaction(context =>
            {
                var complaint = complaintDto.ToAddedEntity(userId);
                context.Set<Complaint>().Add(complaint);
            });
        }

        public void TakeAction(ComplaintActionDto complaintActionDto, string userId)
        {
            Transaction(context =>
            {
                var complaint = GetComplaint(c => c.Id == complaintActionDto.ComplaintId, c => c.ActionLogs);
                complaint.ActionTypeId = complaintActionDto.ActionType;
                complaint.ActionLogs.Add(new ComplaintAction()
                {
                    CreatedByUserId = userId,
                    ActionTypeId = complaintActionDto.ActionType,
                });

                context.Set<Complaint>().Update(complaint);
            });
        }
    }
}
