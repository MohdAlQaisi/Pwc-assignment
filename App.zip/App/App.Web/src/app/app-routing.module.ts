import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { AdminHomeComponent } from './components/admin-home/admin-home.component';
import { CustomerHomeComponent } from './components/customer-home/customer-home.component';
import { LoginComponent } from './components/login/login.component';
import { SignUpComponent } from './components/sign-up/sign-up.component';
import { SubmitComplaintComponent } from './components/submit-complaint/submit-complaint.component';
import { UnauthorizedComponent } from './components/unauthorized/unauthorized.component';
import { AuthGuard } from './shared/common/guards/auth-guard';

export const ROOT_ROUTES: Routes = [
  {
    path: '',
    children: [
      //{
      //  path: AccountKeys.MainRoute,
      //  loadChildren: () => import('./account/account.module').then(m => m.AccountModule)
      //}
    ],
    canActivate: [AuthGuard],
    data: { roles: [] }
  },
  {
    path: '*',
    redirectTo: 'login',
    pathMatch: 'full',
    data: { roles: [] }
  },
  {
    path: 'unauthorized',
    component: UnauthorizedComponent,
    data: { roles: [] }
  },
  {
    path: 'login',
    component: LoginComponent,
    data: { roles: [] }
  },
  {
    path: 'sign-up',
    component: SignUpComponent,
    data: { roles: [] }
  },
  {
    path: 'home',
    canActivate: [AuthGuard],
    component: AdminHomeComponent,
    data: { roles: ['Admin'] }
  },
  {
    path: 'customer',
    canActivate: [AuthGuard],
    component: CustomerHomeComponent,
    data: { roles: ['Customer'] }
  },
  {
    path: 'add-complaint',
    canActivate: [AuthGuard],
    component: SubmitComplaintComponent,
    data: { roles: ['Customer'] }
  }
]

@NgModule({
  imports: [
    RouterModule.forRoot(ROOT_ROUTES, { preloadingStrategy: PreloadAllModules, onSameUrlNavigation: 'reload' }),
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
