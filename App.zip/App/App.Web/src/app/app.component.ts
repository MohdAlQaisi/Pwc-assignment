import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BaseComponent } from './base.component.ts';
import { AuthService } from './services/common/auth.service';
import { TokenHelper } from './services/common/token-helper';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent extends BaseComponent implements OnInit {
  isAuthenticated = TokenHelper.isTokenValid();
  isAdmin = TokenHelper.isAdmin;
  username!: string;

  constructor(private _router: Router) {
    super();
  }

  ngOnInit(): void {
    AuthService.loggedIn.subscribe(res => {
      this.isAuthenticated = TokenHelper.isTokenValid();
      if (!this.isAuthenticated) {
        this._router.navigate(['/login']);
      }
      else {
        TokenHelper.isAdmin = TokenHelper.getUserData().role == "Admin";
        this.isAdmin = TokenHelper.isAdmin;
        this.username = TokenHelper.getUserData().fullName;
      }
    });

    if (!this.isAuthenticated) {
      this._router.navigate(['/login']);
    }
    else {
      TokenHelper.isAdmin = TokenHelper.getUserData().role == "Admin";
      this.isAdmin = TokenHelper.isAdmin;
      this.username = TokenHelper.getUserData().fullName;
      if (this.isAdmin) {
        this._router.navigate(['/home']);
      }
      else {
        this._router.navigate(['/customer']);
      }
    }
  }

  logout() {
    AuthService.logout();
  }
}
