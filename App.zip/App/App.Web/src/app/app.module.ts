import { CommonModule } from '@angular/common';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ErrorHandler, Injector, NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { KanbanModule } from '@syncfusion/ej2-angular-kanban';
import { RichTextEditorModule } from '@syncfusion/ej2-angular-richtexteditor';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { NgxSpinnerModule } from 'ngx-spinner';
import { ToastrModule } from 'ngx-toastr';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdminHomeComponent } from './components/admin-home/admin-home.component';
import { CustomerHomeComponent } from './components/customer-home/customer-home.component';
import { LoginComponent } from './components/login/login.component';
import { SignUpComponent } from './components/sign-up/sign-up.component';
import { SubmitComplaintComponent } from './components/submit-complaint/submit-complaint.component';
import { UnauthorizedComponent } from './components/unauthorized/unauthorized.component';
import { CommonService } from './services/common/common-service';
import { GlobalErrorHandler } from './services/common/global-error-handler';
import { AuthGuard } from './shared/common/guards/auth-guard';
import { AuthInterceptor } from './shared/common/interceptors/auth-interceptor';
import { SpinnerInterceptor } from './shared/common/interceptors/spinner-interceptor';
import { InjectorHelper } from './shared/common/models/injectorHelper';
import { SharedModule } from './shared/shared.module';

@NgModule({
  declarations: [
    AppComponent,
    UnauthorizedComponent,
    LoginComponent,
    SignUpComponent,
    AdminHomeComponent,
    CustomerHomeComponent,
    SubmitComplaintComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    CommonModule,
    FormsModule,
    HttpClientModule,
    ToastrModule.forRoot(),
    NgxSpinnerModule,
    SharedModule.forRoot(),
    PaginationModule.forRoot(),
    RichTextEditorModule,
    KanbanModule
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: SpinnerInterceptor,
      multi: true,
    },
    {
      provide: ErrorHandler,
      useClass: GlobalErrorHandler
    },
    AuthGuard,
    CommonService
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
  constructor(private readonly injector: Injector) {
    InjectorHelper.injector = this.injector;
  }
}
