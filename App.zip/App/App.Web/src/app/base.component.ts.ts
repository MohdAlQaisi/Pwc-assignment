import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'base',
  template: ''
})
export class BaseComponent implements OnInit {
  constructor() { }

  ngOnInit(): void {
  }
}
