import { Component, EventEmitter, OnInit, ViewChild } from '@angular/core';
import { KanbanComponent } from '@syncfusion/ej2-angular-kanban';
import { ActionEventArgs, CardSettingsModel, DialogSettingsModel, DragEventArgs, SwimlaneSettingsModel } from '@syncfusion/ej2-kanban';
import { BaseComponent } from '../../base.component.ts';
import { AlertService } from '../../services/common/alert-service.service';
import { ComplaintService } from '../../services/complaint.service';
import { AlertType, ComplaintActionTypes } from '../../shared/common/enums';
import { Paging } from '../../shared/common/models/app/paging.model';
import { Complaint } from '../../shared/common/models/complaint/complaint.model';

@Component({
  selector: 'app-admin-home',
  templateUrl: './admin-home.component.html'
})
export class AdminHomeComponent extends BaseComponent implements OnInit {
  @ViewChild('kanban') kanban!: KanbanComponent;
  paging = new Paging();
  complaints: Complaint[] = [];
  data: Complaint[] = [];
  cardSettings: CardSettingsModel = {
    contentField: 'descriptionText',
    headerField: 'title'
  };
  public swimlaneSettings: SwimlaneSettingsModel = { keyField: 'creationDate' };

  constructor(private _complaintService: ComplaintService, private _alertService: AlertService) { super(); }

  ngOnInit(): void {
    this.loadComplaints();
    setTimeout(() => {
      let event: EventEmitter<ActionEventArgs>;
      event = (this.kanban.actionComplete as any);
      event.subscribe(res => {
        let temp = res.changedRecords as Array<Complaint>;
        const status = temp[0].status == 'Pending' ? ComplaintActionTypes.Pending : temp[0].status == 'Resolved' ? ComplaintActionTypes.Resolved : ComplaintActionTypes.Dismissed;
        this._complaintService.takeAction({ actionType: status, complaintId: temp[0].id }).subscribe(res => {
          if (res.isSuccess) {
            this._alertService.showAlert('', 'Complaint updated successfully!', AlertType.Success);
          }
        });
      });
    }, 1000);
  }


  loadComplaints(isPager = false) {
    this._complaintService.getComplaints(this.paging.batch, this.paging.batchSize).subscribe(res => {
      this.paging = res.data.paging;
      this.complaints = res.data.list;
    });
  }

  dialogSettings: DialogSettingsModel = {
    fields: [
      { text: 'Title', key: 'title', type: 'TextBox' },
      { text: 'Status', key: 'status', type: 'DropDown' }
    ]
  };
  dragStop(value: DragEventArgs) {

  }
}
