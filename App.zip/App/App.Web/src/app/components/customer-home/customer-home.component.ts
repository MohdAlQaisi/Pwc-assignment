import { Component, OnInit } from '@angular/core';
import { PageChangedEvent } from 'ngx-bootstrap/pagination';
import { BaseComponent } from '../../base.component.ts';
import { ComplaintService } from '../../services/complaint.service';
import { Batch } from '../../shared/common/models/app/batch.model';
import { Paging } from '../../shared/common/models/app/paging.model';
import { Complaint } from '../../shared/common/models/complaint/complaint.model';

@Component({
  selector: 'app-customer-home',
  templateUrl: './customer-home.component.html'
})
export class CustomerHomeComponent extends BaseComponent implements OnInit {
  paging = new Paging();
  complaints: Complaint[] = [];
  batchs: Batch<Complaint>[] = [];
  event: PageChangedEvent = { itemsPerPage: 10, page: 1 };
  isLoading = false;
  constructor(private _complaintService: ComplaintService) { super(); }

  ngOnInit(): void {
    this.loadComplaints();
  }


  loadComplaints(isPager = false) {
    this.isLoading = true;
    if (!isPager) {
      this.batchs = [];
      this.complaints = [];
    }
    this._complaintService.getCustomerComplaints(this.paging.batch, this.paging.batchSize).subscribe(res => {
      this.batchs.push({
        id: res.data.paging.batch,
        results: res.data.list
      });

      this.paging = res.data.paging;
      this.complaints = res.data.list.slice(0, 10);
      this.isLoading = false;
    });
  }

  pageChanged(event: PageChangedEvent): void {
    const currentBatchId = Math.ceil((event.page * event.itemsPerPage) / 100);
    this.event.page = event.page;
    const currentBatch = this.batchs.find(p => p.id == currentBatchId)
    if (currentBatch != null) {
      const startItem = ((event.page - 1) * event.itemsPerPage) - ((currentBatchId - 1) * 100);
      const endItem = (event.page * event.itemsPerPage) - ((currentBatchId - 1) * 100);
      this.complaints = currentBatch.results.slice(startItem, endItem);
    }
    else {
      this.complaints = [];
      this.paging.batch = currentBatchId;
      this.loadComplaints(true);
    }
  }
}
