import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { BaseComponent } from '../../base.component.ts';
import { AlertService } from '../../services/common/alert-service.service';
import { AuthService } from '../../services/common/auth.service';
import { TokenHelper } from '../../services/common/token-helper';
import { AlertType } from '../../shared/common/enums';
import { UserLogin } from '../../shared/common/models/app/user-login.model';
import { User } from '../../shared/common/models/app/user.model';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html'
})
export class LoginComponent extends BaseComponent implements OnInit {
  @ViewChild('logingForm') public logingForm!: NgForm;
  public loginVM: UserLogin = new UserLogin();
  isSubmitted = false;
  constructor(private _authService: AuthService,
    private _router: Router,
    private _alertService: AlertService) { super(); }

  ngOnInit(): void {
    if (TokenHelper.isTokenValid()) {
      this.handleLoggedInUser();
    }
  }

  handleLoggedInUser() {
    const user: User = TokenHelper.getUserData();

    TokenHelper.isAdmin = user.role == "Admin";

    if (TokenHelper.isAdmin) {
      this._router.navigate(['/home']);
    }
    else {
      this._router.navigate(['/customer']);
    }
  }

  authenticate() {
    this.isSubmitted = true;
    if (this.logingForm.valid) {
      this._authService.authenticate(this.loginVM).subscribe(token => {
        this._alertService.showAlert('', 'Logged in successfully', AlertType.Success);

        TokenHelper.setToken(token);

        const user: User = TokenHelper.getUserData();

        TokenHelper.isAdmin = user.role == "Admin";

        this.handleLoggedInUser();

        AuthService.loggedIn.emit(true);
      });
    }
    else {
      this._alertService.showAlert('', 'Please enter email and password!', AlertType.Error);
    }
  }
}
