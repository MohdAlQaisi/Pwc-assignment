import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { BaseComponent } from '../../base.component.ts';
import { AccountService } from '../../services/account.service';
import { AlertService } from '../../services/common/alert-service.service';
import { AuthService } from '../../services/common/auth.service';
import { TokenHelper } from '../../services/common/token-helper';
import { AlertType } from '../../shared/common/enums';
import { ApplicationUser } from '../../shared/common/models/app/app-user.model';
import { User } from '../../shared/common/models/app/user.model';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html'
})
export class SignUpComponent extends BaseComponent implements OnInit {
  @ViewChild('registerForm') public registerForm!: NgForm;
  modelVM: ApplicationUser = new ApplicationUser();
  isAuthenticated = TokenHelper.isTokenValid();
  isSubmitted = false;

  constructor(private _accountService: AccountService,
    private _router: Router,
    private _alertService: AlertService) { super(); }

  ngOnInit(): void {
    if (TokenHelper.isTokenValid()) {
      this.handleLoggedInUser();
    }
  }

  handleLoggedInUser() {
    const user: User = TokenHelper.getUserData();

    TokenHelper.isAdmin = user.role == "Admin";

    if (!TokenHelper.isAdmin) {
      this._router.navigate(['/customer']);
    }
  }

  register() {
    this.isSubmitted = true;
    if (this.registerForm.valid && this.modelVM.password == this.modelVM.confirmPassword) {
      if (TokenHelper.isTokenValid()) {
        this.registerAdmin();
      }
      else {
        this.registerCustomer();
      }
    }
  }

  registerCustomer() {
    this._accountService.registerCustomer(this.modelVM).subscribe(res => {
      if (res.isSuccess) {
        this._alertService.showAlert('', 'User registered successfully', AlertType.Success);

        TokenHelper.setToken(res.data);

        TokenHelper.isAdmin = false;

        this.handleLoggedInUser();

        AuthService.loggedIn.emit(true);
      }
      else {
        this._alertService.showAlert('', res.data, AlertType.Error);
      }
    }, err => {
      this._alertService.showAlert('', 'Cant Add User', AlertType.Error);

      const keys = Object.keys(err.error.errors);
      keys.forEach(key => {
        this._alertService.showAlert('', err.error.errors[key], AlertType.Error);
      });
    });
  }

  registerAdmin() {
    this._accountService.adminRegister(this.modelVM).subscribe(res => {
      if (res.isSuccess) {
        this._alertService.showAlert('', 'User registered successfully', AlertType.Success);
        this._router.navigate(['/home']);
      }
      else {
        this._alertService.showAlert('', res.data, AlertType.Error);
      }
    }, err => {
      this._alertService.showAlert('', 'Cant Add User', AlertType.Error);
      const keys = Object.keys(err.error.errors);
      keys.forEach(key => {
        this._alertService.showAlert('', err.error.errors[key], AlertType.Error);
      });
    });
  }
}
