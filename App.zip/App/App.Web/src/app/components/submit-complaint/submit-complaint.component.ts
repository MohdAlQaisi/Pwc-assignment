import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { HtmlEditorService, ImageService, ImageSettingsModel, LinkService, RichTextEditorComponent, ToolbarService } from '@syncfusion/ej2-angular-richtexteditor';
import { BaseComponent } from '../../base.component.ts';
import { AlertService } from '../../services/common/alert-service.service';
import { ComplaintService } from '../../services/complaint.service';
import { AlertType } from '../../shared/common/enums';
import { Complaint } from '../../shared/common/models/complaint/complaint.model';

@Component({
  selector: 'app-submit-complaint',
  templateUrl: './submit-complaint.component.html',
  providers: [ToolbarService, LinkService, ImageService, HtmlEditorService]
})
export class SubmitComplaintComponent extends BaseComponent implements OnInit {
  @ViewChild('complaintForm') public complaintForm!: NgForm;
  @ViewChild('defaultRTE') public textEditior!: RichTextEditorComponent;
  modelVM: Complaint = new Complaint();
  mode: string = 'Markdown';
  insertImageSettings: ImageSettingsModel = { saveFormat: 'Base64' };
  isSubmitted = false;
  constructor(private _router: Router,
    private _complaintService: ComplaintService,
    private _alertService: AlertService) { super(); }

  ngOnInit(): void {
    this.modelVM.description = '<p>Write Your Complaint Here</p>';
    setTimeout(() => {
      this.textEditior.valueTemplate = this.modelVM.description;
      const sourceCode = document.querySelectorAll('[aria-label="Code View"]');
      sourceCode[0].parentElement?.remove();
    }, 1000);
  }

  sumbitComplaint() {
    this.isSubmitted = true;
    this.modelVM.description = this.textEditior.getHtml();
    this.modelVM.descriptionText = this.textEditior.getText();
    if (this.complaintForm.valid) {
      this._complaintService.submitComplaint(this.modelVM).subscribe(res => {
        if (res.isSuccess) {
          this._alertService.showAlert('', 'Your complaint has been submitted successfully', AlertType.Success);
          this._router.navigate(['/customer']);
        }
        else {
          this._alertService.showAlert('', 'Cant submit your complaint', AlertType.Error);
        }
      }, err => {
        this._alertService.showAlert('', 'Cant submit your complaint', AlertType.Error);
        const keys = Object.keys(err.error.errors);
        keys.forEach(key => {
          this._alertService.showAlert('', err.error.errors[key], AlertType.Error);
        });
      });
    }
    else {
      this._alertService.showAlert('', 'Please fill all required fields', AlertType.Error);
    }
  }
}
