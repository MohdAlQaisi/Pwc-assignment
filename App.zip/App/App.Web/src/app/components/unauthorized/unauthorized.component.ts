import { Component, OnInit } from '@angular/core';
import { BaseComponent } from '../../base.component.ts';

@Component({
  selector: 'unauthorized',
  templateUrl: './unauthorized.component.html',
  styleUrls: ['./unauthorized.component.less']
})
export class UnauthorizedComponent extends BaseComponent implements OnInit {
  constructor() { super(); }

  ngOnInit(): void {
  }
}
