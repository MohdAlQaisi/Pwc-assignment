import { Injectable } from '@angular/core';
import { ActionResultSet } from '../shared/common/interfaces/action-result-set';
import { ApplicationUser } from '../shared/common/models/app/app-user.model';
import { BaseService } from './common/base-service';

@Injectable()
export class AccountService extends BaseService {
  private controllerUrl = "Account/";
  constructor() {
    super();
  }

  registerCustomer(user: ApplicationUser) {
    return this.http.post<ApplicationUser, ActionResultSet<string>>(`${this.controllerUrl}CustomerRegister`, user);
  }

  adminRegister(user: ApplicationUser) {
    return this.http.post<ApplicationUser, ActionResultSet<string>>(`${this.controllerUrl}AdminRegister`, user);
  }
}
