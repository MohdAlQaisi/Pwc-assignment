import { Injectable } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { AlertType } from '../../shared/common/enums';

@Injectable()
export class AlertService {

  constructor(private _toastr: ToastrService) {
  }

  public showAlert(title: string, message: string, alertType: AlertType) {
    switch (alertType) {
      case AlertType.Success:
        this.successAlert(title, message);
        break;
      case AlertType.Error:
        this.errorAlert(title, message);
        break;
      case AlertType.Warning:
        this.warningAlert(title, message);
        break;
      case AlertType.Info:
        this.infoAlert(title, message);
        break;
    }
  }

  public hideAll() {
    this._toastr.clear();
  }

  private successAlert(title: string, message: string) {
    this._toastr.success(message, title);
  }

  private errorAlert(title: string, message: string) {
    this._toastr.error(message, title);
  }

  private infoAlert(title: string, message: string) {
    this._toastr.info(message, title);
  }

  private warningAlert(title: string, message: string) {
    this._toastr.warning(message, title);
  }
}
