export class AppHelper {
  static get isAr() {
    return localStorage.getItem("lang") == "ar";
  }
}
