import { HttpClient, HttpHeaders } from '@angular/common/http';
import { EventEmitter, Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { TokenHelper } from './token-helper';

@Injectable()
export class AuthService {
  private controllerUrl = "Account";
  headers = new HttpHeaders();

  constructor(private http: HttpClient) {
  }

  public static loggedIn: EventEmitter<boolean> = new EventEmitter<boolean>();

  public authenticate(cred: any) {
    return this.http.post(`${environment.apiUrl}${this.controllerUrl}/Login`, cred, { responseType: 'text' });
  }

  static logout() {
    TokenHelper.removeToken();
    localStorage.clear();
    AuthService.loggedIn.emit(false);
  }
}
