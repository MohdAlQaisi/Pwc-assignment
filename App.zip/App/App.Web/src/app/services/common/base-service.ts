import { HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { ActionResultSet } from '../../shared/common/interfaces/action-result-set';
import { HttpService } from './http.service';

@Injectable()
export class BaseService {
  public http: HttpService = new HttpService(environment.apiUrl);
  constructor() {
  }

  public post(url: string, criteria: any) {
    return this.http.post(url, criteria);
  }

  public postFile(url: string, file: any) {
    let formData: FormData = new FormData();
    formData.append('file', file);
    let headers = new HttpHeaders();
    /** In Angular 5, including the header Content-Type can invalidate your request */
    headers.append('Content-Disposition', 'multipart/form-data');
    headers.append('Accept', 'application/json');
    return this.http.post<FormData, ActionResultSet<any>>(`${url}`, formData, headers);
  }

  public get(url: string) {
    return this.http.get(url);
  }
}
