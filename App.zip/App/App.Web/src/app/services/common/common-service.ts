import { EventEmitter, Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable()
export class CommonService {
  constructor(private _router: Router) {
    this.subsecription();
  }

  public static url: string;

  public static languageChange: EventEmitter<boolean> = new EventEmitter<boolean>();

  private subsecription() {
    CommonService.languageChange.subscribe(() => {
      const url = this._router.url;
      if (url != '/') {
        CommonService.url = url;
        this._router.navigate([CommonService.url]);
      }
    })
  }
}
