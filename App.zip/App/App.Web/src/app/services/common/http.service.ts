import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, finalize, map } from 'rxjs/operators';
import { InjectorHelper } from '../../shared/common/models/injectorHelper';

export class HttpService {
  private http: HttpClient;
  baseUrl: string;
  lang = 'ar';
  constructor(env: string) {
    this.baseUrl = env;
    this.http = InjectorHelper.injector.get<HttpClient>(HttpClient);
  }

  public get<TResponse>(url: string, options?: HttpHeaders, showSpinner?: boolean, spinnerName?: string): Observable<TResponse> {
    this.setLang();
    options = this.setOptions(options, showSpinner, spinnerName);
    return this.http.get<TResponse>(this.baseUrl + url, { headers: options }).pipe(
      map(res => this.successOperation(res, this.baseUrl + url)),
      catchError((error: HttpErrorResponse) => { return this.errorOperation(error, this.baseUrl + url); }),
      finalize(() => { this.finallyOperation(); })
    )
  }

  public post<TData, TResponse>(url: string, body: TData, options?: HttpHeaders, showSpinner?: boolean, spinnerName?: string): Observable<TResponse> {
    this.setLang();
    options = this.setOptions(options, showSpinner, spinnerName);
    return this.http.post<TResponse>(this.baseUrl + url, body, { headers: options }).pipe(
      map(res => this.successOperation(res, this.baseUrl + url)),
      catchError((error: HttpErrorResponse) => { return this.errorOperation(error, this.baseUrl + url); }),
      finalize(() => { this.finallyOperation(); })
    )
  }

  public put<TData, TResponse>(url: string, body: any, options?: HttpHeaders, showSpinner?: boolean): Observable<TResponse> {
    this.setLang();
    options = this.setOptions(options, showSpinner);
    return this.http.put<TResponse>(this.baseUrl + url, body, { headers: options }).pipe(
      map(res => this.successOperation(res, this.baseUrl + url)),
      catchError((error: HttpErrorResponse) => { return this.errorOperation(error, this.baseUrl + url); }),
      finalize(() => { this.finallyOperation(); })
    );
  }

  public patch<TResponse>(url: string, options?: HttpHeaders, showSpinner?: boolean): Observable<TResponse> {
    this.setLang();
    options = this.setOptions(options, showSpinner);
    return this.http.patch<TResponse>(this.baseUrl + url, { headers: options }).pipe(
      map(res => this.successOperation(res, this.baseUrl + url)),
      catchError((error: HttpErrorResponse) => { return this.errorOperation(error, this.baseUrl + url); }),
      finalize(() => { this.finallyOperation(); })
    );
  }

  public delete<TResponse>(url: string, options?: HttpHeaders, showSpinner?: boolean): Observable<TResponse> {
    this.setLang();
    options = this.setOptions(options, showSpinner);
    return this.http.delete<TResponse>(this.baseUrl + url, { headers: options }).pipe(
      map(res => this.successOperation(res, this.baseUrl + url)),
      catchError((error: HttpErrorResponse) => { return this.errorOperation(error, this.baseUrl + url); }),
      finalize(() => { this.finallyOperation(); })
    )
  }

  private successOperation(result: any, apiUrl: string) {
    return result;
  }

  private errorOperation(error: HttpErrorResponse, apiUrl: string) {
    return throwError(error);
  }

  private finallyOperation() {

  }

  private setLang() {
    if (localStorage.getItem("lang") != undefined) {
      this.lang = <string>localStorage.getItem("lang");
    }
  }

  private setOptions(options?: HttpHeaders, showSpinner = true, spinnerName?: string): HttpHeaders {
    if (options != undefined) {
      options = options.append('Language', this.lang);
      options = options.append('showSpinner', showSpinner ? 'true' : 'false');
      options = options.append('spinnerName', spinnerName ? spinnerName : '');
    }
    else {
      options = new HttpHeaders({
        'Language': this.lang,
        'showSpinner': showSpinner ? 'true' : 'false',
        'spinnerName': spinnerName ? spinnerName : ''
      });
    }
    return options;
  }
}
