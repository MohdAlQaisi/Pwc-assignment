import { JwtHelperService } from '@auth0/angular-jwt';
import { User } from '../../shared/common/models/app/user.model';

const helper = new JwtHelperService();

export class TokenHelper {
  public static isAdmin: boolean = false;

  public static getToken(): string | null {
    let token = localStorage.getItem('authTicket');
    if (token) {
      return token;
    }
    return null;
  }

  public static setToken(token: string) {
    localStorage.setItem('authTicket', token);
  }

  public static removeToken() {
    localStorage.removeItem('authTicket');
  }

  static isTokenValid(): boolean {
    if (this.getToken() == null) {
      return false;
    }
    this.getTokenExpirationDate(<string>this.getToken());
    const isExpired = helper.isTokenExpired(<string>this.getToken());

    return !isExpired;
  }

  static getUserData(): User {
    const token = helper.decodeToken(<string>this.getToken());
    let user: User = new User();
    if (token) {
      user = {
        id: token.nameid,
        email: token.email,
        role: token.role,
        fullName: token.fullname,
        mobileNumber: token.mobilenumber,
      };
    }
    return user;
  }

  static isExpired(token: string) {
    try {
      const isExpired = helper.isTokenExpired(token);
      return isExpired;
    }
    catch (err) {
      return true;
    }
  }

  static getTokenExpirationDate(token: string): Date | null {
    const decodedToken = helper.decodeToken(token);

    if (decodedToken.exp === undefined) {
      return null;
    }

    const date = new Date(0);
    date.setUTCSeconds(decodedToken.exp);
    return date;
  }

  static getDecodedUserToken(): any {
    if (!TokenHelper.isTokenValid()) {
      return null;
    }
    return helper.decodeToken(TokenHelper.getToken() as string);
  }

  private static getUserRoles(): Array<string> {
    if (!TokenHelper.isTokenValid()) {
      return [];
    }
    let token = this.getDecodedUserToken();
    if (token.hasOwnProperty("role"))
      return token.role;
    else return [];
  }

  static hasRole(roles: Array<string>) {
    if (roles.length == 0)
      return true;
    if (!this.isTokenValid()) {
      return false;
    }
    return roles.some(r => this.getUserRoles().indexOf(r) >= 0) ? true : false;
  }
}
