import { Injectable } from '@angular/core';
import { ActionResultSet } from '../shared/common/interfaces/action-result-set';
import { SearchResult } from '../shared/common/models/app/search-result.model';
import { ComplaintAction } from '../shared/common/models/complaint/complaint-action.model';
import { Complaint } from '../shared/common/models/complaint/complaint.model';
import { BaseService } from './common/base-service';

@Injectable()
export class ComplaintService extends BaseService {
  private controllerUrl = "Complaint/";
  constructor() {
    super();
  }

  getComplaint(id: number) {
    return this.http.get<ActionResultSet<Complaint>>(`${this.controllerUrl}GetComplaint?id=${id}`);
  }

  getComplaints(batch: number, batchSize: number) {
    return this.http.get<ActionResultSet<SearchResult<Complaint>>>(`${this.controllerUrl}GetComplaints?batch=${batch}&batchSize=${batchSize}`);
  }

  getCustomerComplaints(batch: number, batchSize: number) {
    return this.http.get<ActionResultSet<SearchResult<Complaint>>>(`${this.controllerUrl}GetCustomerComplaints?batch=${batch}&batchSize=${batchSize}`);
  }

  submitComplaint(complaint: Complaint) {
    return this.http.post<Complaint, ActionResultSet<boolean>>(`${this.controllerUrl}SubmitComplaint`, complaint);
  }

  takeAction(action: ComplaintAction) {
    return this.http.post<ComplaintAction, ActionResultSet<boolean>>(`${this.controllerUrl}TakeAction`, action);
  }
}
