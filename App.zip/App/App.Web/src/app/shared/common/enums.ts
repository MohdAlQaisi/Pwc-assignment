export enum ComplaintActionTypes {
  Pending = 0,
  Resolved = 1,
  Dismissed = 2,
}

export enum AlertType {
  Success = 1,
  Error = 2,
  Info = 3,
  Warning = 3,
}
