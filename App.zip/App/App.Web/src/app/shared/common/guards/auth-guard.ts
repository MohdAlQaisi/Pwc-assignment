import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from '../../../services/common/auth.service';
import { TokenHelper } from '../../../services/common/token-helper';

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(private _router: Router) { }
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    let roles = route.data["roles"] as Array<string>;
    if (roles.find(x => x == "anonymouse"))
      return true;

    if (TokenHelper.isTokenValid()) {
      let authTicket = TokenHelper.getToken();
      if (authTicket)
        TokenHelper.setToken(authTicket);

      if (TokenHelper.hasRole(roles))
        return true;
      else {
        this._router.navigate(['/unauthorized'], { queryParams: { returnUrl: state.url } });
        return false;
      }
    }
    else {
      this._router.navigate(['/login']);
      return false;
    }
  }
}
