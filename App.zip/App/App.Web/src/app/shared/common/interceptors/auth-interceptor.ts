import { HttpHandler, HttpInterceptor, HttpRequest } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { AppHelper } from "../../../services/common/app-helper";
import { TokenHelper } from '../../../services/common/token-helper';

@Injectable()

export class AuthInterceptor implements HttpInterceptor {
  constructor() { }

  intercept(req: HttpRequest<any>, next: HttpHandler) {
    const language = AppHelper.isAr ? "ar" : "en";
    if (TokenHelper.getToken()) {
      const authToken = TokenHelper.getToken();
      req = req.clone({
        setHeaders: {
          Authorization: "Bearer " + authToken
        }
      });
    }

    req = req.clone({
      setHeaders: {
        "lang": language
      }
    });
    return next.handle(req);
  }
}
