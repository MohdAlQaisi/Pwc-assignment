export class ActionResultSet<T> {
  public isSuccess!: boolean;
  public data!: T;
}
