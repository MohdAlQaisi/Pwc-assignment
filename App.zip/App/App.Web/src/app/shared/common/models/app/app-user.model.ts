export class ApplicationUser {
  public fullName!: string;
  public contactNumber!: string;
  public email!: string;
  public password!: string;
  public confirmPassword?: string;
}
