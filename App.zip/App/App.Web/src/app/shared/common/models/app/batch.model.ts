export class Batch<T> {
  public id!: number;
  public results!: T[];
}
