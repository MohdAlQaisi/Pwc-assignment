export class Paging {
  public batch: number = 1;
  public batchSize: number = 100;
  public totalRecords: number = 0;
}
