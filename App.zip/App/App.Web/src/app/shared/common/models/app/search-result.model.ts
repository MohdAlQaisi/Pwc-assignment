import { Paging } from "./paging.model";

export class SearchResult<T>{
  public list: T[] = [];
  public paging: Paging = new Paging();
}
