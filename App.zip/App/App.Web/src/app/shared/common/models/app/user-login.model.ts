export class UserLogin {
  public email!: string;
  public password!: string;
  public rememberMe: boolean = true;
}
