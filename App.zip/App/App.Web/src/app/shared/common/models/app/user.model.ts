export class User {
  public id!: string;
  public email!: string;
  public mobileNumber?: string;
  public fullName!: string;
  public role!: string;
}
