import { ComplaintActionTypes } from "../../enums";

export class ComplaintAction {
  public complaintId!: number;
  public actionType!: ComplaintActionTypes;
}
