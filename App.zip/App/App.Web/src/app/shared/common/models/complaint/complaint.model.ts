import { ComplaintActionTypes } from "../../enums";
import { ApplicationUser } from "../app/app-user.model";

export class Complaint {
  public id!: number;
  public title!: string;
  public type?: string;
  public description!: string;
  public descriptionText!: string;
  public status!: string;
  public statusId!: ComplaintActionTypes;
  public createdBy!: ApplicationUser;
  public creationDate!: string;
}
