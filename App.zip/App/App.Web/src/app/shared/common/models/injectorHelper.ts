import { Injector } from '@angular/core';

export class InjectorHelper {
  public static injector: Injector;
}
