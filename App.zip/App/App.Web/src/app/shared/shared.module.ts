import { CommonModule } from '@angular/common';
import { Injector, NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { AccountService } from '../services/account.service';
import { AlertService } from '../services/common/alert-service.service';
import { AuthService } from '../services/common/auth.service';
import { BaseService } from '../services/common/base-service';
import { ComplaintService } from '../services/complaint.service';
import { InjectorHelper } from './common/models/injectorHelper';
import { SharedRoutingModule } from './shared-routing.module';

export const routes: Routes = []

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule,
    SharedRoutingModule,
  ],
  exports: [
    CommonModule,
    RouterModule
  ],
  providers: [
    AlertService,
    AccountService,
    ComplaintService
  ],
  declarations: [
  ]
})
export class SharedModule {
  static forRoot() {
    return {
      ngModule: SharedModule,
      providers: [
        CommonModule,
        FormsModule,
        BaseService,
        AuthService,
        AccountService,
        ComplaintService
      ]
    }
  }

  static forChild() {
    return {
      ngModule: SharedModule,
      providers: []
    }
  }
  constructor(private readonly injector: Injector) {
    InjectorHelper.injector = this.injector;
  }
}
