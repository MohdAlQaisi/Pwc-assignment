export const environment = {
  production: true,
  apiUrl: 'http://mohdqaisi1995-001-site1.itempurl.com/api/'
};
